#!/bin/bash
# Paramos y borramos la versión anterior del portal, si existe
sudo docker stop sisinf-database
sudo docker rm sisinf-database
cd postgres
unzip main.zip
sudo docker build -t carlota/postgresql:latest .
sudo docker run --name sisinf-database -e POSTGRES_USER=carlota -e POSTGRES_PASSWORD=contra -e ALLOW_EMPTY_PASSWORD=no -e POSTGRESQL_DATABASE=estampatuestilo -p 5432:5432 -d carlota/postgresql:latest

cd ..
# Paramos y borramos la versión anterior del portal, si existe
sudo docker stop sisinf-tomcat
sudo docker rm sisinf-tomcat
cd tomcat
sudo docker build -t carlota/tomcat:latest .
sudo docker run -d --name sisinf-tomcat --link sisinf-database -e ALLOW_EMPTY_PASSWORD=yes -p 8080:8080 carlota/tomcat:latest
