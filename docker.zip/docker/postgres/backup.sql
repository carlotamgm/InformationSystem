--
-- PostgreSQL database dump
--

-- Dumped from database version 14.10 (Ubuntu 14.10-1.pgdg20.04+1)
-- Dumped by pg_dump version 14.10 (Ubuntu 14.10-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: administrador; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.administrador (
    email character varying NOT NULL,
    "contraseña" character varying(25) NOT NULL
);


ALTER TABLE public.administrador OWNER TO carlota;

--
-- Name: camiseta; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.camiseta (
    idcamiseta integer NOT NULL,
    imagen character varying(100),
    texto text,
    esfavorita character varying(2),
    talla character varying(1),
    idmodelo character varying(25),
    CONSTRAINT ch_esfavorita CHECK (((esfavorita)::text = ANY ((ARRAY['si'::character varying, 'no'::character varying])::text[]))),
    CONSTRAINT ch_tallacam CHECK (((talla)::text = ANY ((ARRAY['S'::character varying, 'M'::character varying, 'L'::character varying])::text[])))
);


ALTER TABLE public.camiseta OWNER TO carlota;

--
-- Name: camiseta_idcamiseta_seq; Type: SEQUENCE; Schema: public; Owner: carlota
--

CREATE SEQUENCE public.camiseta_idcamiseta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.camiseta_idcamiseta_seq OWNER TO carlota;

--
-- Name: camiseta_idcamiseta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carlota
--

ALTER SEQUENCE public.camiseta_idcamiseta_seq OWNED BY public.camiseta.idcamiseta;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.cliente (
    email character varying NOT NULL,
    "contraseña" character varying(25),
    nombreusuario character varying(25) NOT NULL
);


ALTER TABLE public.cliente OWNER TO carlota;

--
-- Name: encarga; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.encarga (
    idencarga integer NOT NULL,
    calle character varying(25) NOT NULL,
    numero integer NOT NULL,
    mailcliente character varying(20),
    numpedido integer NOT NULL
);


ALTER TABLE public.encarga OWNER TO carlota;

--
-- Name: encarga_idencarga_seq; Type: SEQUENCE; Schema: public; Owner: carlota
--

CREATE SEQUENCE public.encarga_idencarga_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encarga_idencarga_seq OWNER TO carlota;

--
-- Name: encarga_idencarga_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carlota
--

ALTER SEQUENCE public.encarga_idencarga_seq OWNED BY public.encarga.idencarga;


--
-- Name: incluye; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.incluye (
    numpedido integer NOT NULL,
    numcamiseta integer NOT NULL
);


ALTER TABLE public.incluye OWNER TO carlota;

--
-- Name: modelo; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.modelo (
    nommodelo character varying(25) NOT NULL,
    precio double precision NOT NULL,
    esvisible character varying(2),
    mailadmin character varying(20) NOT NULL,
    imagen character varying(100) NOT NULL,
    CONSTRAINT ch_esvisible CHECK (((esvisible)::text = ANY ((ARRAY['si'::character varying, 'no'::character varying])::text[]))),
    CONSTRAINT modelo_precio_check CHECK ((precio > (0.0)::double precision))
);


ALTER TABLE public.modelo OWNER TO carlota;

--
-- Name: pedido; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.pedido (
    idpedido integer NOT NULL,
    precio double precision,
    estado character varying(10),
    estapagado character varying(2),
    CONSTRAINT ch_estado CHECK (((estado)::text = ANY ((ARRAY['en cesta'::character varying, 'solicitado'::character varying, 'en reparto'::character varying, 'recibido'::character varying])::text[]))),
    CONSTRAINT ch_estapagado CHECK (((estapagado)::text = ANY ((ARRAY['si'::character varying, 'no'::character varying])::text[]))),
    CONSTRAINT ch_precio CHECK ((precio >= (0.0)::double precision))
);


ALTER TABLE public.pedido OWNER TO carlota;

--
-- Name: pedido_idpedido_seq; Type: SEQUENCE; Schema: public; Owner: carlota
--

CREATE SEQUENCE public.pedido_idpedido_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_idpedido_seq OWNER TO carlota;

--
-- Name: pedido_idpedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: carlota
--

ALTER SEQUENCE public.pedido_idpedido_seq OWNED BY public.pedido.idpedido;


--
-- Name: talla; Type: TABLE; Schema: public; Owner: carlota
--

CREATE TABLE public.talla (
    talla character varying(1) NOT NULL,
    idmodelo character varying(25) NOT NULL,
    numcamisetas integer NOT NULL,
    CONSTRAINT ch_tallamod CHECK (((talla)::text = ANY ((ARRAY['S'::character varying, 'M'::character varying, 'L'::character varying])::text[])))
);


ALTER TABLE public.talla OWNER TO carlota;

--
-- Name: camiseta idcamiseta; Type: DEFAULT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.camiseta ALTER COLUMN idcamiseta SET DEFAULT nextval('public.camiseta_idcamiseta_seq'::regclass);


--
-- Name: encarga idencarga; Type: DEFAULT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.encarga ALTER COLUMN idencarga SET DEFAULT nextval('public.encarga_idencarga_seq'::regclass);


--
-- Name: pedido idpedido; Type: DEFAULT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.pedido ALTER COLUMN idpedido SET DEFAULT nextval('public.pedido_idpedido_seq'::regclass);


--
-- Data for Name: administrador; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.administrador (email, "contraseña") FROM stdin;
admin@gmail.com	admin123
\.


--
-- Data for Name: camiseta; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.camiseta (idcamiseta, imagen, texto, esfavorita, talla, idmodelo) FROM stdin;
\.


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.cliente (email, "contraseña", nombreusuario) FROM stdin;
carlota@gmail.com	car123	car
paula@gmail.com	pauli123	pauli
aroa@gmail.com	aroa123	aroita
invitado		invitado
\.


--
-- Data for Name: encarga; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.encarga (idencarga, calle, numero, mailcliente, numpedido) FROM stdin;
\.


--
-- Data for Name: incluye; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.incluye (numpedido, numcamiseta) FROM stdin;
\.


--
-- Data for Name: modelo; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.modelo (nommodelo, precio, esvisible, mailadmin, imagen) FROM stdin;
camiseta blanca	14	si	admin@gmail.com	images/camiseta_blanca.png
tirantes	14	si	admin@gmail.com	images/camiseta_tirantes.png
unamanga	7	si	admin@gmail.com	images/camiseta_unamanga.png
rayas	10	si	admin@gmail.com	images/camiseta_rayas.png
camiseta	14	si	admin@gmail.com	images/camiseta_rayas_mangalarga.png
\.


--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.pedido (idpedido, precio, estado, estapagado) FROM stdin;
\.


--
-- Data for Name: talla; Type: TABLE DATA; Schema: public; Owner: carlota
--

COPY public.talla (talla, idmodelo, numcamisetas) FROM stdin;
S	camiseta blanca	12
L	rayas	5
S	camiseta	14
M	tirantes	5
M	rayas	15
M	unamanga	7
\.


--
-- Name: camiseta_idcamiseta_seq; Type: SEQUENCE SET; Schema: public; Owner: carlota
--

SELECT pg_catalog.setval('public.camiseta_idcamiseta_seq', 1, false);


--
-- Name: encarga_idencarga_seq; Type: SEQUENCE SET; Schema: public; Owner: carlota
--

SELECT pg_catalog.setval('public.encarga_idencarga_seq', 1, false);


--
-- Name: pedido_idpedido_seq; Type: SEQUENCE SET; Schema: public; Owner: carlota
--

SELECT pg_catalog.setval('public.pedido_idpedido_seq', 1, false);


--
-- Name: administrador administrador_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.administrador
    ADD CONSTRAINT administrador_pkey PRIMARY KEY (email);


--
-- Name: camiseta camiseta_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.camiseta
    ADD CONSTRAINT camiseta_pkey PRIMARY KEY (idcamiseta);


--
-- Name: cliente cliente_nombreusuario_key; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_nombreusuario_key UNIQUE (nombreusuario);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (email);


--
-- Name: encarga encarga_numpedido_key; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.encarga
    ADD CONSTRAINT encarga_numpedido_key UNIQUE (numpedido);


--
-- Name: encarga encarga_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.encarga
    ADD CONSTRAINT encarga_pkey PRIMARY KEY (idencarga);


--
-- Name: incluye incluye_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.incluye
    ADD CONSTRAINT incluye_pkey PRIMARY KEY (numpedido, numcamiseta);


--
-- Name: modelo modelo_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.modelo
    ADD CONSTRAINT modelo_pkey PRIMARY KEY (nommodelo);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (idpedido);


--
-- Name: talla talla_pkey; Type: CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.talla
    ADD CONSTRAINT talla_pkey PRIMARY KEY (talla, idmodelo);


--
-- Name: camiseta camiseta_idmodelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.camiseta
    ADD CONSTRAINT camiseta_idmodelo_fkey FOREIGN KEY (idmodelo) REFERENCES public.modelo(nommodelo);


--
-- Name: encarga encarga_mailcliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.encarga
    ADD CONSTRAINT encarga_mailcliente_fkey FOREIGN KEY (mailcliente) REFERENCES public.cliente(email);


--
-- Name: encarga encarga_numpedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.encarga
    ADD CONSTRAINT encarga_numpedido_fkey FOREIGN KEY (numpedido) REFERENCES public.pedido(idpedido);


--
-- Name: incluye incluye_numcamiseta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.incluye
    ADD CONSTRAINT incluye_numcamiseta_fkey FOREIGN KEY (numcamiseta) REFERENCES public.camiseta(idcamiseta);


--
-- Name: incluye incluye_numpedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.incluye
    ADD CONSTRAINT incluye_numpedido_fkey FOREIGN KEY (numpedido) REFERENCES public.pedido(idpedido);


--
-- Name: modelo modelo_mailadmin_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.modelo
    ADD CONSTRAINT modelo_mailadmin_fkey FOREIGN KEY (mailadmin) REFERENCES public.administrador(email);


--
-- Name: talla talla_idmodelo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: carlota
--

ALTER TABLE ONLY public.talla
    ADD CONSTRAINT talla_idmodelo_fkey FOREIGN KEY (idmodelo) REFERENCES public.modelo(nommodelo);


--
-- PostgreSQL database dump complete
--

